<div class="sidebar mt-5">
    <ul>
        <li class="dash <?php echo $title;?> fs-5 ms-3"><i class="fa-solid fa-circle"></i><a href="./dashboard.php"><i class="mx-3 fa-solid fa-gauge-high"></i>  Dashboard</a></li>
        <li class="ord <?php echo $title;?> fs-5 ms-3 "><i class="fa-solid fa-circle"></i><a href="./my-order.php"><i class="mx-3 fa-solid fa-cart-arrow-down"></i> My Orders</a></li>
        <li class="wish <?php echo $title;?> fs-5 ms-3"><i class="fa-solid fa-circle"></i><a href="./wishlist.php"><i class="mx-3 fa-solid fa-heart"></i> My Wishlist</a></li>
        <li class="rev <?php echo $title;?> fs-5 ms-3"><i class="fa-solid fa-circle"></i><a href="./my-review.php"><i class="mx-3 fa-solid fa-comment-dots"></i> My Reviews</a></li>
        <li class="addr <?php echo $title;?> fs-5 ms-3"><i class="fa-solid fa-circle"></i><a href="./my-address.php"><i class="mx-3 fa-solid fa-address-book"></i> My Address</a></li>
        <li class="pro <?php echo $title;?> fs-5 ms-3"><i class="fa-solid fa-circle"></i><a href="./my-profile.php"><i class="mx-3 fa-solid fa-user-tie"></i> My Profile</a></li>
        <li class=" fs-5 ms-3"></i><a href=""><i class="mx-3 fa-solid fa-right-from-bracket"></i> Logout</a></li>
    </ul>

</div>