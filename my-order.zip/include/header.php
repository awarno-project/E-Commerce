<div class="container-fluid header mx-0 px-0 row border-bottom  ">
    <div class="logo col-12 col-md-3 d-flex align-items-ceter">
        <img src="https://cdn.pixabay.com/photo/2018/01/14/23/05/ecommerce-3082813__340.jpg" alt="">      
        <!-- image should be changed by company logo  -->
    </div>
    <div class="icon col-12 col-md-4 d-flex justify-content-center align-items-ceter">
        <a href="#"><i class="fa-solid fa-phone"></i> Contact </a>
        <p class="mx-3 my-0"> | </p>  
        <a href="#"><i class="fa-solid fa-user"></i> Account</a> 

    </div>
</div>